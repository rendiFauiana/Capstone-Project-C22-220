document.addEventListener('DOMContentLoaded', () => {
    const mapsContainer = document.querySelector('#maps');
    mapsContainer.innerHTML = createMaps();

    const buttonMaps = document.querySelector('#buttonMaps');
    buttonMaps.addEventListener('click', () => {
        console.log(buttonMaps.value);
        const sourceUrl = buttonMaps.value;
        mapsContainer.innerHTML = '';
        mapsContainer.innerHTML = createMaps(sourceUrl);
    })
})

const createMaps = (sourceUrl = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.6663076376294!2d106.82267427325937!3d-6.17540833122916!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f5d2db8c5617%3A0x4e446b7ac891d847!2sMonas%2C%20Gambir%2C%20Kecamatan%20Gambir%2C%20Kota%20Jakarta%20Pusat%2C%20Daerah%20Khusus%20Ibukota%20Jakarta!5e0!3m2!1sid!2sid!4v1668710551664!5m2!1sid!2sid") => `
    <iframe src="${sourceUrl}" width="530" height="240" style="border:0;" allowfullscreen="" 
    loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
`;